from django.apps import AppConfig


class ChatgroupConfig(AppConfig):
    name = 'chatgroup'
