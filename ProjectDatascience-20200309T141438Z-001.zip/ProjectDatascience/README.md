# Datascience_10min
* ลง git bash https://git-scm.com/downloads
* เปิด git bash cd ไปที่ Desktop ตามด้วย git clone https://github.com/DDoS000/Datascience_10min.git
* หลังจากนั้นลง python-3.8.2.exe Dowloadมาไว้ให้แล้ว
* เปิด pj ใน vscode เปิด terminal 
* pip install pipenv
* pipenv shell
* pipenv install
* รอออออออออออออ....................
